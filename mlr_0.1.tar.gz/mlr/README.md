# mlr_r_package
An R Package for basic operations in R

to install

```devtools::install_github("mitchelllisle/mlr_package")```
