library(testthat)
library(mlr)

test_check("mlr")
